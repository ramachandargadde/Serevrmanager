from django.shortcuts import render ,redirect
from .models import Server

# Create your views here.
def index(request):
    server = Server.objects.all()
    if request.method =='POST':
        new_server=Server(
            title=request.POST['title']
        )
        new_server.save()
        return redirect('/')
    return render(request,'index.html',{'servers':server})
def delete(request,pk):
    server=Server.objects.get(id=pk)
    server.delete()
    return redirect('/')
